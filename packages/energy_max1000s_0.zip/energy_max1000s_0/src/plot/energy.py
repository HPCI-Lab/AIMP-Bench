
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

USE_CASES = ["A", "B", "C"]
TIME = 1000
NAME = f"energy_max{TIME}s"
import yprov4dv
yprov4dv.start_run(provenance_directory=NAME, run_name=NAME)

ELEC_TABLE = {
    "A40": 0.30,
    "L40S": 0.35,
    "RTX8000": 0.295,
    "V100": 0.30,
}

all_samples = []

for USE_CASE in USE_CASES: 
    BASE_PATHS = { 
        "A40": f"prov/BENCH.{USE_CASE}.A40",
        "L40S": f"prov/BENCH.{USE_CASE}.L40S",
        "RTX8000": f"prov/BENCH.{USE_CASE}.RTX8000",
        "V100": f"prov/BENCH.{USE_CASE}.V100",
    }

    all_pathss = [[os.path.join(B, f) for f in os.listdir(B)] for B in BASE_PATHS.values()]
    all_paths = []
    for apss in all_pathss: 
        all_paths.extend(apss)

    for BASE_PATH in all_paths:
        PATH = os.path.join(BASE_PATH, "metrics_GR0", "gpu_usage_Context.TRAINING_GR0.csv")
        GPU = BASE_PATH.split("/")[1].split(".")[-1]
        try: 
            data = pd.read_csv(PATH)
        except: 
            continue
        exp_name = BASE_PATH.split("/")[-1]

        start = int(data["LoggingItemKind.SYSTEM_METRIC"][0])
        end = int(data["LoggingItemKind.SYSTEM_METRIC"][len(data)-1])

        gu = (data["Context.TRAINING"] * ELEC_TABLE[GPU]).mean()

        if (end-start) / 1000 > TIME: continue
        if data["Context.TRAINING"].mean() > 1: continue

        d = {"time": (end-start) / 1000, "energy_consumption": gu, "GPU": GPU, "UC": USE_CASE}

        all_samples.append(d)

samples = pd.DataFrame(all_samples)

sns.scatterplot(samples, x="energy_consumption", y="time", hue="GPU", style="UC")
plt.savefig(f"{NAME}.png", dpi=300)
plt.close()
